﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

//check for how many times the chain lightning has been used.
//loop
//if chainLenght is less than 3 then
//spawn another lightning through the chain reaction
// Use this for initialization

public class SubLightningScript : MonoBehaviour {

    public ChainReaction mainLightningScript;
    public GameObject subLightning;
    public Vector3 subLightningOffset;
    List<GameObject> targetsMarked = new List<GameObject>();

    private int chainUsage;
    private int maxChainReactions;

    
    void Start ()
    {
        chainUsage = mainLightningScript.chainUsed;
        maxChainReactions = mainLightningScript.chainLenght;
	}

    //adds the first three enemies onto the list of marked enemies from the sub-Reaction lightning
    //sets off the subLightning chain-reaction

    void OntriggerEnter(Collider other)
    {
        if(other.tag == "Enemy")
        {
            chainUsage = mainLightningScript.chainLenght;
            targetsMarked.Add(other.gameObject);
            SubChainReaction();
        }
    }

    //for each enemy in the list spawn a lightning prefab
    void SubChainReaction()
    {
        //spawn all the chain reactions that are left from the main lightning spell
        for (; chainUsage < maxChainReactions; chainUsage++)
        {
            GameObject subLightningSpawn = (GameObject)Instantiate(subLightning, targetsMarked[chainUsage].transform.position + subLightningOffset, targetsMarked[chainUsage].transform.rotation); //instantiates the gameObject
            subLightningSpawn.transform.parent = targetsMarked[chainUsage].transform; //make sublightning a child of the enemy GO
        }   
    }
    
}
