﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ChainReaction : MonoBehaviour {

    //Public variables
    //GameObject to instantiate
    public GameObject subLightning;
    public int chainUsed;
    public int chainLenght = 3; //can be changed, needs to be reference through the sub-script
    public Vector3 subLightningOffset; //offset the sub-lightning prefab 

    //private variables
    private Targeter myTargeter; //script
    //list of enemies marked
    List<GameObject> targetsMarked = new List<GameObject>(); //does not have to be a list, use gameObject instead
    
    // Use this for initialization
    void Start()
    {
        chainUsed = 0;
        myTargeter = gameObject.GetComponent<Targeter>();
    }

    //adds enemies onto my list
    //Sets off main lightning chain reaction
    void OnTriggerEnter(Collider other)
    {
        StatsHandler otherStats = other.GetComponent<StatsHandler>();
        if (other.tag == "Enemy" && otherStats != null)
        {
            //get the gameObject of the enemy within the list, adds the latest GO to enter the trigger 
            targetsMarked.Add(other.gameObject);
            SpawnTriggers(); //can only do 3 at a time
        }
    }

    //use the list to instantiate subLightning triggers
    void SpawnTriggers()
    {
        for(; chainUsed < chainLenght; chainUsed++) //for the first three that hit the main lightning
        {
            GameObject subLightningSpawn = (GameObject)Instantiate(subLightning, targetsMarked[chainUsed].transform.position + subLightningOffset, targetsMarked[chainUsed].transform.rotation); //instantiates the gameObject
            subLightningSpawn.transform.parent = targetsMarked[chainUsed].transform; //make sublightning a child of the enemy GO
        }

        //Empty the list of enemies once the max of enemies is affected
    }
}
